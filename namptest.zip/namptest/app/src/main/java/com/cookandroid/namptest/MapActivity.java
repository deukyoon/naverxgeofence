package com.cookandroid.namptest;

import android.content.pm.PackageManager;
import android.os.Bundle;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.naver.maps.geometry.LatLng;

import com.naver.maps.map.LocationTrackingMode;
import com.naver.maps.map.MapFragment;
import com.naver.maps.map.NaverMap;
import com.naver.maps.map.OnMapReadyCallback;
import com.naver.maps.map.overlay.CircleOverlay;
import com.naver.maps.map.overlay.OverlayImage;
import com.naver.maps.map.util.FusedLocationSource;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    //NaverMap 객체에 위치 소스를 지정하고 권한 설정
    private static final int PERMISSION_REQUEST_CODE = 100;
    private static final String[] PERMISSION = {
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION,
            android.Manifest.permission.ACCESS_BACKGROUND_LOCATION
    };

    private NaverMap mNaverMap;
    private FusedLocationSource mLocationSource;

    private CircleOverlay mCircleOverlay;

    private final double GEOFENCE_LATITUDE = 37.379865723701;
    private final double GEOFENCE_LONGITUDE =126.928810441112;
    private final float GEOFENCE_RADIUS = 200; // meter



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MapFragment mapFragment = (MapFragment) getSupportFragmentManager().findFragmentById(R.id.map_fragment);
        mapFragment.getMapAsync(this);

        //위치 요청 응답
        mLocationSource =
                new FusedLocationSource(this, PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onMapReady(NaverMap naverMap) {
        mNaverMap = naverMap;

        // NaverMap 객체에 위치 소스 지정
        mNaverMap = naverMap;
        mNaverMap.setLocationSource(mLocationSource);

        // 권한 확인, onRequestPermissionsResult 콜백 메서드 호출
        ActivityCompat.requestPermissions(this, PERMISSION, PERMISSION_REQUEST_CODE);


        //지오펜스 설정
        LatLng geofenceCenter = new LatLng(GEOFENCE_LATITUDE, GEOFENCE_LONGITUDE);

        mCircleOverlay = new CircleOverlay();
        mCircleOverlay.setCenter(geofenceCenter);
        mCircleOverlay.setRadius(GEOFENCE_RADIUS);
        mCircleOverlay.setColor(0x220000FF);
        mCircleOverlay.setOutlineColor(0xFF0000FF);
        mCircleOverlay.setOutlineWidth(2);

        mCircleOverlay.setMap(mNaverMap);

        // 입장시 토스트 메세지 출력
        mNaverMap.addOnLocationChangeListener(location -> {
            if (location.getLatitude() > GEOFENCE_LATITUDE - 0.0005 &&
                    location.getLatitude() < GEOFENCE_LATITUDE + 0.0005 &&
                    location.getLongitude() > GEOFENCE_LONGITUDE - 0.0005 &&
                    location.getLongitude() < GEOFENCE_LONGITUDE + 0.0005) {
                Toast.makeText(MapActivity.this, "You are inside the Geofence!", Toast.LENGTH_SHORT).show();
            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        // 권한 획득 여부 확인
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mNaverMap.setLocationTrackingMode(LocationTrackingMode.Follow);
            }
        }
    }
}
